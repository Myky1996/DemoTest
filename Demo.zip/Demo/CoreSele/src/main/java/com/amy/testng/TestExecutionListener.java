package com.amy.testng;

import com.amy.utils.LogUtils;
import com.amy.utils.ScreenshotUtils;
import com.amy.webdriver.Driver;
import com.amy.webdriver.DriverManager;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.internal.Utils;

public class TestExecutionListener implements ITestListener {
    private static final LogUtils logback = LogUtils.getInstance();

    @Override
    public void onTestStart(ITestResult iTestResult) {
        // Do nothing
        logback.info("******************Beginning TC's "
                + iTestResult.getMethod().getMethodName().trim()
                +"******************");
    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) {
        // Do nothing
        logback.info("******************Ending TC's name: "
                + iTestResult.getMethod().getMethodName().trim()
                + " is PASSED ******************");
    }

    @Override
    public void onTestFailure(ITestResult iTestResult) {
        Driver driver = DriverManager.getDriver();
        String methodName = iTestResult.getMethod().getMethodName().trim();

        ScreenshotUtils.attachScreenshotToReport(methodName,driver);

        logback.info("******************Ending TC's name: "
                + methodName
                + " is FAILED ******************");
    }
    @Override
    public void onTestSkipped(ITestResult iTestResult) {
        Driver driver = DriverManager.getDriver();
        String methodName = iTestResult.getMethod().getMethodName().trim();

        logback.error(Utils.longStackTrace(iTestResult.getThrowable(), false));

        ScreenshotUtils.attachScreenshotToReport(methodName,driver);

        logback.info("****************** TC's name: "
                + iTestResult.getMethod().getMethodName().trim()
                + " is SKIPPED since PRE-CONDITIONS OR POST-CONDITIONS OR RETRY TEST ARE ERROR ******************");
    }
    @Override
    public void onStart(ITestContext iTestContext) {
        // Do nothing
    }
    @Override
    public void onFinish(ITestContext iTestContext) {}

}
