package com.amy;

import lombok.Getter;
import lombok.Setter;


public class Environment {
    @Getter
    @Setter
    String dashboardURL;
    @Getter
    @Setter
    String baseURL;

}