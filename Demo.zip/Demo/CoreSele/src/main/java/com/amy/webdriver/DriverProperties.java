package com.amy.webdriver;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class DriverProperties {
    private String browserName;
    private  String deviceName;
    private  String methodName;
}
