package page;

public class BasePage {
}
